package com.example.taskflow.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.taskflow.data.Task
import com.example.taskflow.repository.TaskRepository
import com.example.taskflow.workers.ReminderWorker
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class AddEditTaskViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = TaskRepository.getInstance(app)

    fun save(task: Task, scheduleReminder: Boolean = true) = viewModelScope.launch {
        val id = repo.upsert(task)
        val remindAt = task.remindAt
        if (scheduleReminder && remindAt != null && remindAt > System.currentTimeMillis()) {
            val delay = remindAt - System.currentTimeMillis()
            val work = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(Data.Builder().putLong("taskId", id).build())
                .build()
            WorkManager.getInstance(getApplication()).enqueue(work)
        }
    }
}