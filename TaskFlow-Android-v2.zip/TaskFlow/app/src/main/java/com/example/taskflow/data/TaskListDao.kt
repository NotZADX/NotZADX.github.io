package com.example.taskflow.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskListDao {
    @Query("SELECT * FROM task_lists ORDER BY name ASC")
    fun observeLists(): Flow<List<TaskList>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(list: TaskList): Long

    @Delete
    suspend fun delete(list: TaskList)
}