package com.example.taskflow.theme

import androidx.compose.material3.Typography

val AppTypography = Typography()