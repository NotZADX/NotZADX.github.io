package com.example.taskflow.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.taskflow.data.Task
import com.example.taskflow.util.DateTimeUtils
import com.example.taskflow.viewmodel.AddEditTaskViewModel
import java.util.*

@Composable
fun AddEditTaskScreen(nav: NavHostController, taskId: Long?) {
    val ctx = LocalContext.current
    val vm: AddEditTaskViewModel = viewModel()

    var title by remember { mutableStateOf(TextFieldValue("")) }
    var notes by remember { mutableStateOf(TextFieldValue("")) }
    var dueAt by remember { mutableStateOf<Long?>(null) }
    var remindAt by remember { mutableStateOf<Long?>(null) }
    var priority by remember { mutableStateOf(1) }
    var duration by remember { mutableStateOf(60) }

    Scaffold(topBar = { TopAppBar(title = { Text("Add task") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val cal = Calendar.getInstance()
                    DatePickerDialog(ctx, { _, y, m, d ->
                        cal.set(Calendar.YEAR, y); cal.set(Calendar.MONTH, m); cal.set(Calendar.DAY_OF_MONTH, d)
                        TimePickerDialog(ctx, { _, hh, mm ->
                            cal.set(Calendar.HOUR_OF_DAY, hh); cal.set(Calendar.MINUTE, mm); cal.set(Calendar.SECOND, 0)
                            dueAt = cal.timeInMillis
                        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
                    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                }) { Text(if (dueAt == null) "Pick due" else DateTimeUtils.formatDateTime(dueAt)) }

                Button(onClick = {
                    val cal = Calendar.getInstance()
                    DatePickerDialog(ctx, { _, y, m, d ->
                        cal.set(Calendar.YEAR, y); cal.set(Calendar.MONTH, m); cal.set(Calendar.DAY_OF_MONTH, d)
                        TimePickerDialog(ctx, { _, hh, mm ->
                            cal.set(Calendar.HOUR_OF_DAY, hh); cal.set(Calendar.MINUTE, mm); cal.set(Calendar.SECOND, 0)
                            remindAt = cal.timeInMillis
                        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
                    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                }) { Text(if (remindAt == null) "Pick reminder" else DateTimeUtils.formatDateTime(remindAt)) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Priority:")
                AssistChip(onClick = { priority = 0 }, label = { Text("Low") }, selected = priority == 0)
                AssistChip(onClick = { priority = 1 }, label = { Text("Normal") }, selected = priority == 1)
                AssistChip(onClick = { priority = 2 }, label = { Text("High") }, selected = priority == 2)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Duration (min):")
                var text by remember { mutableStateOf(duration.toString()) }
                OutlinedTextField(value = text, onValueChange = {
                    text = it.filter { ch -> ch.isDigit() }.take(4)
                    duration = text.toIntOrNull() ?: 0
                }, modifier = Modifier.width(120.dp))
            }

            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val task = Task(
                    title = title.text.trim(),
                    notes = notes.text.trim().ifBlank { null },
                    dueAt = dueAt,
                    remindAt = remindAt,
                    durationMinutes = duration,
                    priority = priority
                )
                vm.save(task, scheduleReminder = true)
                nav.popBackStack()
            }, enabled = title.text.isNotBlank()) {
                Text("Save")
            }
        }
    }
}