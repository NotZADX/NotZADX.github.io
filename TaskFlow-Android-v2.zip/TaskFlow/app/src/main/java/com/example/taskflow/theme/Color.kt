package com.example.taskflow.theme

import androidx.compose.ui.graphics.Color

val md_theme_light_primary = Color(0xFF006874)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_background = Color(0xFFFBFCFE)
val md_theme_light_onBackground = Color(0xFF191C1D)

val md_theme_dark_primary = Color(0xFF4DD8EA)
val md_theme_dark_onPrimary = Color(0xFF00363D)
val md_theme_dark_background = Color(0xFF191C1D)
val md_theme_dark_onBackground = Color(0xFFE1E3E4)