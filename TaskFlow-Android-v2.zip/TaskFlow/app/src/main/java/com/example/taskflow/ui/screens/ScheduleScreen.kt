package com.example.taskflow.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.taskflow.ui.components.TaskItem
import com.example.taskflow.viewmodel.TaskViewModel

@Composable
fun ScheduleScreen(nav: NavHostController) {
    val vm: TaskViewModel = viewModel()
    val tasks = vm.tasks.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Schedule") }) }) { padding ->
        Column(Modifier.padding(padding).padding(12.dp)) {
            Text("All Upcoming Tasks", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks.value, key = { it.id }) { task ->
                    TaskItem(task, onComplete = { vm.toggleComplete(task) }, onDelete = { vm.delete(task) })
                }
            }
        }
    }
}