package com.example.taskflow.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun SettingsScreen(nav: NavHostController) {
    var notifications by remember { mutableStateOf(true) }
    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Preferences", style = MaterialTheme.typography.titleLarge)
            Row {
                Switch(checked = notifications, onCheckedChange = { notifications = it })
                Spacer(Modifier.width(8.dp))
                Text("Enable notifications")
            }
            Text("More settings (language, theme, backups) can be added here.")
        }
    }
}