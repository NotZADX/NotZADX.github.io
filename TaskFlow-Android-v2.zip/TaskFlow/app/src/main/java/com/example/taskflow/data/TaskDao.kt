package com.example.taskflow.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY CASE priority WHEN 2 THEN 0 WHEN 1 THEN 1 ELSE 2 END, COALESCE(dueAt, 4102444800000), orderInList ASC")
    fun observeActiveTasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 AND dueAt IS NOT NULL AND dueAt BETWEEN :start AND :end ORDER BY COALESCE(dueAt, 4102444800000) ASC, priority DESC")
    fun observeTasksBetween(start: Long, end: Long): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 AND (dueAt IS NULL OR dueAt < :start) ORDER BY priority DESC, orderInList ASC")
    fun observeInbox(start: Long): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Task?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: Task): Long

    @Delete
    suspend fun delete(task: Task)

    @Query("UPDATE tasks SET isCompleted = 1 WHERE id = :id")
    suspend fun complete(id: Long)

    @Query("UPDATE tasks SET orderInList = :order WHERE id = :id")
    suspend fun updateOrder(id: Long, order: Int)
}