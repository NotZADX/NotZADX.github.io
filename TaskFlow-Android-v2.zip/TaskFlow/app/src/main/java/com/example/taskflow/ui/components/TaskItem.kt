package com.example.taskflow.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.taskflow.data.Task
import com.example.taskflow.util.DateTimeUtils

@Composable
fun TaskItem(
    task: Task,
    onComplete: (Task) -> Unit,
    onDelete: (Task) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = task.isCompleted, onCheckedChange = { onComplete(task) })
            Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (!task.notes.isNullOrBlank()) {
                    Text(task.notes!!, style = MaterialTheme.typography.bodySmall)
                }
                val meta = buildString {
                    if (task.dueAt != null) append(DateTimeUtils.formatDateTime(task.dueAt))
                    if (task.priority == 2) append(" • ").append("High")
                    else if (task.priority == 0) append(" • ").append("Low")
                }
                if (meta.isNotBlank()) {
                    Text(meta, style = MaterialTheme.typography.labelSmall)
                }
            }
            TextButton(onClick = { onDelete(task) }) {
                Text("Delete")
            }
        }
    }
}