package com.example.taskflow.util

import java.text.SimpleDateFormat
import java.util.*

object DateTimeUtils {
    fun formatDateTime(millis: Long?): String {
        if (millis == null) return ""
        val cal = Calendar.getInstance()
        cal.timeInMillis = millis
        val now = Calendar.getInstance()
        val pattern = if (cal.get(Calendar.YEAR) == now.get(Calendar.YEAR)) {
            "EEE, d MMM • h:mm a"
        } else {
            "EEE, d MMM yyyy • h:mm a"
        }
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
    }
}