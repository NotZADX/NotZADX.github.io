package com.example.taskflow.repository

import android.content.Context
import androidx.room.Room
import com.example.taskflow.data.AppDatabase
import com.example.taskflow.data.Task
import kotlinx.coroutines.flow.Flow
import com.example.taskflow.data.TaskDao

class TaskRepository private constructor(context: Context) {

    private val db: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "taskflow.db"
    ).fallbackToDestructiveMigration().build()

    private val taskDao: TaskDao = db.taskDao()

    fun observeActiveTasks(): Flow<List<Task>> = taskDao.observeActiveTasks()

    fun observeTasksBetween(start: Long, end: Long) = taskDao.observeTasksBetween(start, end)

    suspend fun upsert(task: Task): Long = taskDao.upsert(task)

    suspend fun delete(task: Task) = taskDao.delete(task)

    suspend fun getById(id: Long) = taskDao.getById(id)

    suspend fun complete(id: Long) = taskDao.complete(id)

    suspend fun updateOrder(id: Long, order: Int) = taskDao.updateOrder(id, order)

    companion object {
        @Volatile private var INSTANCE: TaskRepository? = null
        fun getInstance(context: Context): TaskRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: TaskRepository(context).also { INSTANCE = it }
            }
    }
}