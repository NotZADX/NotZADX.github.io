package com.example.taskflow.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String? = null,
    val dueAt: Long? = null,           // millis
    val remindAt: Long? = null,        // millis
    val durationMinutes: Int? = null,
    val priority: Int = 1,             // 0 low, 1 normal, 2 high
    val listId: Long? = null,
    val isCompleted: Boolean = false,
    val orderInList: Int = 0,
    val repeatType: String = "NONE",   // NONE, DAILY, WEEKLY, MONTHLY, YEARLY
    val repeatInterval: Int? = null,   // e.g., every N days/weeks
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)