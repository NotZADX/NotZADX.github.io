# TaskFlow (Android)

A modern, lightweight Android app for tracking tasks and scheduling reminders — built with **Kotlin**, **Jetpack Compose**, **Room**, and **WorkManager**.

## Features
- Add tasks with title, notes, due date/time, reminder, duration, and priority.
- "Today & Upcoming" home showing your next items.
- Local offline storage (Room).
- Reliable reminders (WorkManager) with notification channel.
- Material You design, dark mode, Arabic & English strings.
- Clean architecture (Repository + ViewModels).

## Quick Start (Android Studio)
1. Extract the ZIP.
2. Open **Android Studio** → **Open** → select the project folder.
3. Let Gradle sync. If Android Studio prompts to update dependencies, accept.
4. Connect your Android device (enable USB debugging) or start an emulator.
5. Build → *Build APKs* (or Run ▶). Install and enjoy.

> Note: This project uses Kotlin 1.9.24, AGP 8.5.0, compile/target SDK 34. Android Studio may suggest newer stable versions — it’s safe to upgrade.

## FAQ
- **Where’s the APK?** You can generate it via *Build → Build APK(s)*. This lets you sign it with your own key if you wish.
- **Notifications on Android 13+:** Grant notification permission when prompted.
- **Exact alarms:** WorkManager is used for robust reminders without extra permissions.
- **Backups:** The Room DB is included in Android’s full‑backup by default (see `res/xml/backup_rules.xml`).

## License
MIT — do whatever you want, no warranty.